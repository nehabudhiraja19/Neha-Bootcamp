package com.springbootcamp.springsecurity;

import com.springbootcamp.springsecurity.entities.*;
import com.springbootcamp.springsecurity.repository.BuyerRepository;
import com.springbootcamp.springsecurity.repository.CategoryRepository;
import com.springbootcamp.springsecurity.repository.SellerRepository;
import com.springbootcamp.springsecurity.repository.UserRepository;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;

import java.util.Arrays;
import java.util.HashSet;

@SpringBootTest
class SpringSecurityApplicationTests {


	//creating object of role
//	Role role1=new Role("SELLER");
//	Role role2=new Role("BUYER");
//	Role role3=new Role("ADMIN");
//
//
//	@Autowired
//	UserRepository userRepository;
//
//	@Autowired
//	SellerRepository sellerRepository;
//
//	@Autowired
//	BuyerRepository buyerRepository;
//
//	@Autowired
//	BCryptPasswordEncoder bCryptPasswordEncoder;
//
//
//	@Autowired
//	CategoryRepository categoryRepository;

	@Test
	void contextLoads()
	{

	}

//	@Test
//	public void createSeller()
//	{
//		Seller seller=new Seller();
//		seller.setUsername("Nehab19");
//		seller.setFirstName("Neha");
//		seller.setMiddleName("Singh");
//		seller.setLastName("Budhiraja");
//		seller.setEmail("nehabuddhiraja3@gmail.com");
//		seller.setIs_active(false);
//		seller.setIS_DELETED(false);
//		seller.setRole(Arrays.asList(role1));
//		seller.setPassword(bCryptPasswordEncoder.encode("Nehabudhiraja@123"));
//		seller.setGST(12f);
//		seller.setCompany_contact("9871164092");
//		seller.setCompany_name("TTN");
//		sellerRepository.save(seller);
//
//	}
//
//	@Test
//	public void createBuyer()
//	{
//		Buyer buyer=new Buyer();
//		buyer.setUsername("Shreya19");
//		buyer.setFirstName("Shreya");
//		buyer.setMiddleName("Singh");
//		buyer.setLastName("Mago");
//		buyer.setEmail("smago47@gmail.com");
//		buyer.setPassword(bCryptPasswordEncoder.encode("Shreya@123"));
//		buyer.setIs_active(false);
//		buyer.setIS_DELETED(false);
//		buyer.setContact("8826074092");
//		buyer.setRole(Arrays.asList(role2));
//		buyerRepository.save(buyer);
//
//
//	}
//
//	@Test
//	public void createAddress()
//	{
//
//		User user=userRepository.findByUsername("Nehab19");
//		HashSet<Address>addressList=new HashSet<Address>();
//		Address address1=new Address();
//		address1.setCity("New delhi");
//		address1.setCountry("India");
//		address1.setAddressLabel("West-Patel Nagar");
//		address1.setLabel("Shadipur");
//		address1.setState("Delhi");
//		address1.setZipCode(110008);
//		addressList.add(address1);
//
//
//
//		Address address2=new Address();
//		address1.setCity("New delhi");
//		address1.setCountry("India");
//		address1.setAddressLabel("East-Patel Nagar");
//		address1.setLabel("Patel Nagar");
//		address1.setState("Delhi");
//		address1.setZipCode(110008);
//		addressList.add(address2);
//		address2.setUser(user);
//		user.setAddressSet(addressList);
//		userRepository.save(user);
//
//
//	}
//
//	@Test
//	public void addCategoryOne()
//	{
//		Category category=new Category();
//		category.setName("Books");
//		categoryRepository.save(category);
//
//	}
//
//	@Test
//	public void addCategoryTwo()
//
//	{
//
//		Category category=new Category();
//		category.setName("Mobiles");
//		categoryRepository.save(category);
//
//	}
//	@Test
//	public void addSubCategoryOne()
//	{
//		Category categoryList=categoryRepository.findByCategoryName("Books");
//		Category category=new Category();
//		category.setName("Love Stories");
//		category.setCategory(categoryList);
//		categoryRepository.save(category);
//	}
//
//	@Test
//	public void addSubCategoryTwo()
//	{
//		Category categoryList=categoryRepository.findByCategoryName("Books");
//		Category category=new Category();
//		category.setName("Fiction Stories");
//		category.setCategory(categoryList);
//		categoryRepository.save(category);
//	}
//
//	@Test
//	public void addSubCategoryThree()
//	{
//		Category categoryList=categoryRepository.findByCategoryName("Mobiles");
//		Category category=new Category();
//		category.setName("Samsung");
//		category.setCategory(categoryList);
//		categoryRepository.save(category);
//	}
//
//	@Test
//	public void addSubCategoryFour()
//	{
//		Category categoryList=categoryRepository.findByCategoryName("Mobiles");
//		Category category=new Category();
//		category.setName("Iphone");
//		category.setCategory(categoryList);
//		categoryRepository.save(category);
//	}
//
//
//	@Test
//	public void addProductOne()
//	{
//
//	}
//
//

}
