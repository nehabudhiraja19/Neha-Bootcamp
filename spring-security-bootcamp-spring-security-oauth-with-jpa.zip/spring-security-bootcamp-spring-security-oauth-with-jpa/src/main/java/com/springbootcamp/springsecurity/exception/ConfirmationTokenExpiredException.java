package com.springbootcamp.springsecurity.exception;

public class ConfirmationTokenExpiredException extends RuntimeException
{
    public ConfirmationTokenExpiredException(String message)
    {
        super(message);
    }

    public ConfirmationTokenExpiredException() {

    }
}
