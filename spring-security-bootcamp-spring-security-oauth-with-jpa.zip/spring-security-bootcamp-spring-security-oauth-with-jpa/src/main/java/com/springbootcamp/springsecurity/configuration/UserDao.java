package com.springbootcamp.springsecurity.configuration;

import com.springbootcamp.springsecurity.entities.Role;
import com.springbootcamp.springsecurity.entities.User;

import com.springbootcamp.springsecurity.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.stereotype.Repository;

import java.util.LinkedList;
import java.util.List;

@Repository
public class UserDao {

    @Autowired
    UserRepository userRepository;


    AppUser loadUserByUsername(String username)
    {
        System.out.println("In User dao");
        User user = userRepository.findByUsername(username);
        List<GrantedAuthority> grantedAuthorities = new LinkedList<>();
        for (Role role : user.getRole()){
            grantedAuthorities.add(new SimpleGrantedAuthority(role.getAuthority()));
        }
        System.out.println("Out of user dao");
        System.out.println(user);
        if (username != null)
        {
            return new AppUser(user.getUsername(), user.getPassword(), grantedAuthorities,user.isIS_ACTIVE(),user.nonLocked);
            //return new AppUser(user.getUsername(),user.getPassword(),Arrays.asList(new GrantAuthorityImpl(user.getRole())));
        } else
        {
            throw new RuntimeException();
        }


    }
}
