package com.springbootcamp.springsecurity.entities;

import javax.persistence.*;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import java.sql.Date;
import java.sql.Timestamp;
import java.util.Calendar;
import java.util.List;
import java.util.Set;
@Entity
@PrimaryKeyJoinColumn(name="user_id")
public class Buyer extends User
{


    @NotNull
    @Pattern( regexp ="(\\+91|0)[0-9]{9}")
    private String contact;

   @OneToMany(mappedBy = "buyer", cascade = CascadeType.ALL,fetch = FetchType.LAZY)
    private Set<OrderClass>orderSet;

    @OneToMany(mappedBy = "buyer",cascade = CascadeType.ALL,fetch = FetchType.LAZY)
    private Set<ProductReview>productReviewSet;

    @OneToOne(cascade = CascadeType.ALL,mappedBy = "buyer")
    private Cart cart;


    public Set<OrderClass> getOrderSet() {
        return orderSet;
    }

    public void setOrderSet(Set<OrderClass> orderSet) {
        this.orderSet = orderSet;
    }

    public Set<ProductReview> getProductReviewSet() {
        return productReviewSet;
    }

    public void setProductReviewSet(Set<ProductReview> productReviewSet) {
        this.productReviewSet = productReviewSet;
    }

    public String getContact() {
        return contact;
    }

    public void setContact(String contact) {
        this.contact = contact;
    }

    public Cart getCart() {
        return cart;
    }

    public void setCart(Cart cart) {
        this.cart = cart;
    }

    public void setRole(List<Role> role) {
        this.roles = role;
    }

    public void setConfirmationToken(String confirmationToken) {
        this.confirmationToken = confirmationToken;
    }



    public void setExpiryDate(int expiryTimeInMinutes) {

        Calendar cal = Calendar.getInstance();
        cal.setTime(new Timestamp(cal.getTime().getTime()));
        cal.add(Calendar.MINUTE, expiryTimeInMinutes);
        this.expiryDate = new Date(cal.getTime().getTime());;

    }


    public void setIs_active(Boolean is_active)
    {
        this.IS_ACTIVE = is_active;
    }

}
