package com.springbootcamp.springsecurity.entities;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Set;
@Entity
public class Cart implements Serializable
{
    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE,generator = "cart_gerator")
    @SequenceGenerator(name="cart_generator",sequenceName="cart_seq",allocationSize=1)
    private Long cartId;
    private Integer quantity;
    private boolean isWishListItem;


    @OneToOne(cascade = CascadeType.ALL,fetch = FetchType.LAZY)
    @JoinColumn(name="customer_user_id")
    private Buyer buyer;



    @ManyToMany
    @JoinTable(name = "cart_productVariations ",joinColumns = @JoinColumn(name="cart_id",
            referencedColumnName = "cartId"),
            inverseJoinColumns = @JoinColumn(name="productVariation_id",referencedColumnName = "productVariationId"))
    private Set<ProductVariation> productVariations;


    public Integer getQuantity() {
        return quantity;
    }

    public void setQuantity(Integer quantity) {
        this.quantity = quantity;
    }

    public boolean isWishListItem() {
        return isWishListItem;
    }

    public void setWishListItem(boolean isWishListITEM) {
        this.isWishListItem = isWishListITEM;
    }

    public Buyer getBuyer() {
        return buyer;
    }

    public void setBuyer(Buyer buyer) {
        this.buyer = buyer;
    }

    public Long getId() {
        return cartId;
    }

    public void setId(Long cartId) {
        this.cartId = cartId;
    }

    public Set<ProductVariation> getProductVariations() {
        return productVariations;
    }

    public void setProductVariations(Set<ProductVariation> productVariations) {
        this.productVariations = productVariations;
    }
}
