package com.springbootcamp.springsecurity.controller;

import com.springbootcamp.springsecurity.configuration.AppUser;
import com.springbootcamp.springsecurity.configuration.AppUserDetailsService;
import com.springbootcamp.springsecurity.configuration.UserDao;
import com.springbootcamp.springsecurity.dto.LoginDto;
import com.springbootcamp.springsecurity.entities.User;
import com.springbootcamp.springsecurity.exception.NotFoundException;
import com.springbootcamp.springsecurity.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.DisabledException;
import org.springframework.security.authentication.LockedException;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.oauth2.common.OAuth2AccessToken;
import org.springframework.security.oauth2.provider.endpoint.TokenEndpoint;
import org.springframework.web.HttpRequestMethodNotSupportedException;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.security.Principal;
import java.util.HashMap;

@RestController
public class LoginController

{
    @Autowired
    UserRepository userRepository;

    @Autowired
    UserDao userDao;

    @Autowired
    AppUserDetailsService appUserDetailsService;

    @Autowired
    TokenEndpoint tokenEndpoint;



    @PostMapping("/login")
    public ResponseEntity<OAuth2AccessToken> loginCustomer(Principal principal, @Valid @RequestParam String username, @RequestParam String password, @RequestParam String client_id, @RequestParam String client_secret, @RequestParam String grant_type) throws HttpRequestMethodNotSupportedException, HttpRequestMethodNotSupportedException {

        UserDetails user = appUserDetailsService.loadUserByUsername(username);
        System.out.println("making a token");
        System.out.println(principal);
        if (user == null) {
            throw new NotFoundException("There is no user with such username");
        } else if (user.isAccountNonLocked() == false) {
            throw new LockedException("User Account is locked");
        } else if (user.isEnabled() == false) {
            throw new DisabledException("User Account is disabled");
        } else {
            System.out.println("starting making");
            HashMap<String, String> parameters = new HashMap<>();
            parameters.put("client_id", client_id);
            parameters.put("client_secret", client_secret);
            parameters.put("grant_type", grant_type);
            parameters.put("password", user.getPassword());
            parameters.put("username", user.getUsername());
            parameters.put("scope", "app");

            System.out.println("token is still in making");
            //ResponseEntity<OAuth2AccessToken> accessToken=
            OAuth2AccessToken token= (OAuth2AccessToken) tokenEndpoint.postAccessToken(principal,parameters);
           // OAuth2AccessToken stored = readAccessToken(String.valueOf(token));
            System.out.println(token);
            return (ResponseEntity<OAuth2AccessToken>) token; // System.out.println("token done");
        }
    }
}
