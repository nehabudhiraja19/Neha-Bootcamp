package com.springbootcamp.springsecurity.controller;

import com.springbootcamp.springsecurity.entities.Buyer;
import com.springbootcamp.springsecurity.entities.Seller;
import com.springbootcamp.springsecurity.entities.User;
import com.springbootcamp.springsecurity.exception.NotFoundException;
import com.springbootcamp.springsecurity.exception.emailAlreadyExistsException;
import com.springbootcamp.springsecurity.repository.BuyerRepository;
import com.springbootcamp.springsecurity.repository.SellerRepository;
import com.springbootcamp.springsecurity.repository.UserRepository;
import com.springbootcamp.springsecurity.services.BuyerService;
import com.springbootcamp.springsecurity.services.EmailService;
import com.springbootcamp.springsecurity.services.SellerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.*;
import javax.validation.Valid;
import java.util.Calendar;
import java.util.UUID;

@RestController
public class RegisterController {

    @Autowired
    SellerService sellerService;

    @Autowired
    SellerRepository sellerRepository;

    @Autowired
    BuyerService buyerService;

    @Autowired
    BuyerRepository buyerRepository;

    @Autowired
    EmailService emailService;


    @Autowired
    UserRepository userRepository;


    @PostMapping("/seller/register")
    public String CreateUserSeller(@Valid @RequestBody Seller seller, HttpServletRequest request) {
        Seller SellerExists = sellerRepository.findByEmail(seller.getEmail());
        System.out.println(SellerExists);
        if (SellerExists != null) {
            throw new emailAlreadyExistsException("User already exists with this Email-id");
        }

        String message = sellerService.addSeller(seller);

        String appUrl = request.getScheme() + "://" + request.getServerName();
        String url= "To confirm you email-address, please click the link below: \n" +appUrl+"confirm/seller?token="
                 + seller.getConfirmationToken();
        emailService.sendEmail(seller.getEmail(),url,"Registration confirmation");

        return message;




    }

    @PostMapping("/buyer/register")
    public String CreateUserBuyer(@Valid @RequestBody Buyer buyer, HttpServletRequest request)
    {
        Buyer BuyerExists = buyerRepository.findByEmail(buyer.getEmail());
        System.out.println(BuyerExists);
        if (BuyerExists != null)
        {
            throw new emailAlreadyExistsException("A User already exists with this Email-id");
        }

        String message = buyerService.addBuyer(buyer);
        String appUrl = request.getScheme() + "://" + request.getServerName();
        String url= "To confirm you email-address, please click the link below: \n" +appUrl+"confirm/buyer?token="
                + buyer.getConfirmationToken();
        emailService.sendEmail(buyer.getEmail(),url,"Registration confirmation");

        return message;

    }


    @PutMapping("/confirm/seller")
    public ResponseEntity<String> confirmSellerRegistration(@RequestParam String token, HttpServletRequest request) {
        System.out.println("Entering confirm seller call");
        Seller seller = sellerRepository.findByConfirmationToken(token);
        System.out.println(seller);
        System.out.println(seller.getConfirmationToken());
        if (seller == null) {
            throw new NotFoundException();
        }

        Calendar cal = Calendar.getInstance();
        if ((seller.getExpiryDate().getTime() - cal.getTime().getTime()) <= 0) {
            {

                System.out.println("Error ....Token Expired");

            }
            seller.setConfirmationToken(UUID.randomUUID().toString());
            seller.setExpiryDate(1);
            sellerRepository.save(seller);
            String appUrl = request.getScheme() + "://" + request.getServerName();
            String url= "To confirm you email-address, please click the link below: \n" +appUrl+"confirm/seller?token="
                    + seller.getConfirmationToken();
            emailService.sendEmail(seller.getEmail(),url,"Registration confirmation");

        } else {
            if (seller.getConfirmationToken().equals(token)) {
                System.out.println("Activated..");
                seller.setIs_active(true);
                seller.setConfirmationToken("NULL");
                sellerRepository.save(seller);
            }
        }
            return new ResponseEntity("Seller Registration done!.",HttpStatus.OK);

    }


    @PutMapping("/confirm/buyer")
    public ResponseEntity<String> confirmBuyerRegistration(@RequestParam String token, HttpServletRequest request) {
        System.out.println("Entering into confirm buyer..");
        Buyer buyer = buyerRepository.findByConfirmationToken(token);
        System.out.println(buyer);
        System.out.println(buyer.confirmationToken);
        if (buyer == null) {
            throw new NotFoundException();
        }
        Calendar cal = Calendar.getInstance();
        if ((buyer.getExpiryDate().getTime() - cal.getTime().getTime()) <= 0) {
            {

                System.out.println("Error...Token expired..");
            }
            buyer.setConfirmationToken(UUID.randomUUID().toString());
            buyer.setExpiryDate(1);
            buyerRepository.save(buyer);
            String message = buyerService.addBuyer(buyer);
            String appUrl = request.getScheme() + "://" + request.getServerName();
            String url= "To confirm you email-address, please click the link below: \n" +appUrl+"confirm/buyer?token="
                    + buyer.getConfirmationToken();
            emailService.sendEmail(buyer.getEmail(),url,"Registration confirmation");

        } else {
            if (buyer.getConfirmationToken().equals(token)) {
                System.out.println("Activated..");
                buyer.setIs_active(true);
                buyer.setConfirmationToken("NULL");
                buyerRepository.save(buyer);
            }
        }
        return new ResponseEntity("Buyer Registration confirmed!.",HttpStatus.OK);
    }

    @PostMapping("/reactivationlink/seller")
    public void reactivationLinkSeller(@Valid @RequestParam String Email, HttpServletRequest request) {
        User user = userRepository.findByEmail(Email);
        if (user.isIS_ACTIVE() == false) {
            user.setConfirmationToken(UUID.randomUUID().toString());
            user.setExpiryDate(1);
            userRepository.save(user);
            String appUrl = request.getScheme() + "://" + request.getServerName();
            String url= "To confirm your e-mail address, Please continue with the new activation link and confirm your registration with the link below:\n" +appUrl+"confirm/buyer?token="
                    + user.getConfirmationToken();
            emailService.sendEmail(user.getEmail(),url,"Registration confirmation");

        }

    }

    @PostMapping("/reactivationlink/buyer")
    public void reactivationLinkBuyer(@Valid @RequestParam String Email, HttpServletRequest request) {
        User user = userRepository.findByEmail(Email);
        if (user.isIS_ACTIVE() == false) {
            user.setConfirmationToken(UUID.randomUUID().toString());
            user.setExpiryDate(1);
            userRepository.save(user);
            String appUrl = request.getScheme() + "://" + request.getServerName();
            String url= "To confirm your e-mail address, Please continue with the new activation link and confirm your registration with the link below:\n" +appUrl+"confirm/buyer?token="
                    + user.getConfirmationToken();
            emailService.sendEmail(user.getEmail(),url,"Registration confirmation");



        }

    }
}
