package com.springbootcamp.springsecurity.exception;

public class emailAlreadyExistsException extends RuntimeException
{

    public emailAlreadyExistsException(String msg)
    {
        super(msg);
    }
}
