package com.springbootcamp.springsecurity.controller;

import com.springbootcamp.springsecurity.dto.ResetPasswordDto;
import com.springbootcamp.springsecurity.entities.User;
import com.springbootcamp.springsecurity.exception.EmailNotValidException;
import com.springbootcamp.springsecurity.exception.PasswordNotMatchException;
import com.springbootcamp.springsecurity.repository.UserRepository;
import com.springbootcamp.springsecurity.services.EmailService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;
import java.util.Calendar;
import java.util.UUID;

@RestController
public class ResetPasswordController {

    @Autowired
    UserRepository userRepository;

    @Autowired
    EmailService emailService;

    @Autowired
    BCryptPasswordEncoder bCryptPasswordEncoder;


    @PostMapping("/receiveToken")
    public String ReceiveToken(@Valid @RequestParam String Email, HttpServletRequest request)
    {
        User user = userRepository.findByEmail(Email);

        if (user==null)
        {

            System.out.println("Entering exception");
            throw new EmailNotValidException("Email not valid.");
        }
         else
             {
            user.setConfirmationToken(UUID.randomUUID().toString());
            user.setExpiryDate(1);
            userRepository.save(user);
            String appUrl = request.getScheme() + "://" + request.getServerName();
            SimpleMailMessage registrationEmail = new SimpleMailMessage();
            registrationEmail.setTo(user.getEmail());
            registrationEmail.setSubject("Regeneration Token");
            registrationEmail.setText("The token has been regenerated, Please continue with the new  link and confirm with the link below to reset the password:\n"
                    + appUrl + "/resetPassword?token=" + user.getConfirmationToken());
            registrationEmail.setFrom("noreply@domain.com");

            emailService.sendEmail(registrationEmail);

        }
        return "New activation link has been send to your email-id";
    }

    @PutMapping("/resetPassword")
    public String ResetPassword(@Valid @RequestParam ResetPasswordDto resetPasswordDto) {
        User user1 = userRepository.findByConfirmationToken(resetPasswordDto.getConfirmPassword());
       Calendar cal = Calendar.getInstance();
        if ((user1.getExpiryDate().getTime() - cal.getTime().getTime()) <= 0)
        {
            user1.setConfirmationToken("NULL");
            return "Error...Token expired. The password cannot be updated.....";

        }
    else
            {
                if(!resetPasswordDto.getPassword().equals(resetPasswordDto.getConfirmPassword()))
                {
                    throw new PasswordNotMatchException("Password did not match");
                }
                String newPassword=bCryptPasswordEncoder.encode(resetPasswordDto.getPassword());
                user1.setConfirmationToken("NULL");
                userRepository.save(user1);

                return "Password saved successfully";


            }
        }
    }
