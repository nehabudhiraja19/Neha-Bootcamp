package com.springbootcamp.springsecurity.entities;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Set;

@Entity
public class ProductVariation implements Serializable
{
    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE,generator = "productVariation_generator")
    @SequenceGenerator(name="productVariation_generator",sequenceName="productVariation_seq")
    private Long productVariationId;
    private Integer QUANTITY_AVAILABLE;
    private Long price;

    @Column(columnDefinition = "JSON")
    private String metadata;

    private String primary_image_name;


    @ManyToOne
    @JoinColumn(name = "product_id")
    private Product product;


    @ManyToMany(cascade = CascadeType.ALL,fetch = FetchType.LAZY,mappedBy = "productVariations")
    private Set<Cart> cartSet;


    @OneToOne(cascade = CascadeType.ALL,fetch = FetchType.LAZY,mappedBy = "productVariation")
    private OrderProduct orderProduct;


    public Product getProduct() {
        return product;
    }

    public void setProduct(Product product) {
        this.product = product;
    }

    public OrderProduct getOrderProduct() {
        return orderProduct;
    }

    public void setOrderProduct(OrderProduct orderProduct) {
        this.orderProduct = orderProduct;
    }



    public Long getId() {
        return productVariationId;
    }

    public void setId(Long productVariationId) {
        this.productVariationId = productVariationId;
    }

    public Integer getQUANTITY_AVAILABLE() {
        return QUANTITY_AVAILABLE;
    }

    public void setQUANTITY_AVAILABLE(Integer QUANTITY_AVAILABLE) {
        this.QUANTITY_AVAILABLE = QUANTITY_AVAILABLE;
    }

    public Long getPrice() {
        return price;
    }

    public void setPrice(Long price) {
        this.price = price;
    }

    public String getMetadata() {
        return metadata;
    }

    public void setMetadata(String metadata) {
        this.metadata = metadata;
    }

    public String getPrimary_image_name() {
        return primary_image_name;
    }

    public Set<Cart> getCartSet() {
        return cartSet;
    }

    public void setCartSet(Set<Cart> cartSet) {
        this.cartSet = cartSet;
    }

    public void setPrimary_image_name(String primary_image_name) {
        this.primary_image_name = primary_image_name;
    }
}
