package com.springbootcamp.springsecurity.exception;

import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.HttpRequestMethodNotSupportedException;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

import java.util.Date;

@ControllerAdvice
@RestController

public class ExceptionHandling extends ResponseEntityExceptionHandler
{
    public class CustomizedExceptionSeller extends ResponseEntityExceptionHandler
    {
        @ExceptionHandler(Exception.class)
        public final ResponseEntity<Object> handleAllExceptions(Exception ex, WebRequest request) {
            ExceptionResource exceptionResource = new ExceptionResource(new Date(), ex.getMessage(),
                    request.getDescription(false));
            return new ResponseEntity(exceptionResource, HttpStatus.INTERNAL_SERVER_ERROR);
        }

    }

    @ExceptionHandler(emailAlreadyExistsException.class)
    public final ResponseEntity<Object> handleEmailAlreadyExistsExceptions(emailAlreadyExistsException ex, WebRequest request)
    {
        ExceptionResource exceptionResource=new ExceptionResource(new Date(),"Email already Exists",
                request.getDescription(false));
        return  new ResponseEntity(exceptionResource, HttpStatus.IM_USED);
    }


    @ExceptionHandler(ConfirmationTokenExpiredException.class)
    public final ResponseEntity<Object> handleTokenNotFoundExceptions(ConfirmationTokenExpiredException ex, WebRequest request)
    {
        ExceptionResource exceptionResource=new ExceptionResource(new Date(),"Token Expired",
                request.getDescription(false));
        return  new ResponseEntity(exceptionResource, HttpStatus.EXPECTATION_FAILED);
    }

    @ExceptionHandler(NotFoundException.class)
    public final ResponseEntity<Object> handleUserNotFoundExceptions(NotFoundException ex, WebRequest request)
    {
        ExceptionResource exceptionResource=new ExceptionResource(new Date(),"User Not Found..",
                request.getDescription(false));
        return  new ResponseEntity(exceptionResource, HttpStatus.NOT_FOUND);
    }

    @ExceptionHandler(PasswordNotMatchException.class)
    public final ResponseEntity<Object> handlePasswordNotFoundExceptions(PasswordNotMatchException ex, WebRequest request)
    {
        ExceptionResource exceptionResource=new ExceptionResource(new Date(),"Password was not matched..",
                request.getDescription(false));
        return  new ResponseEntity(exceptionResource, HttpStatus.NOT_ACCEPTABLE);
    }

    @ExceptionHandler(EmailNotValidException.class)
    public final ResponseEntity<Object> handleEmailNotValid(EmailNotValidException ex, WebRequest request)
    {
        ExceptionResource exceptionResource=new ExceptionResource(new Date(),"Email was not valid.",
                request.getDescription(false));
        return  new ResponseEntity(exceptionResource, HttpStatus.NOT_ACCEPTABLE);
    }



    @Override
    protected ResponseEntity<Object> handleMethodArgumentNotValid(
            MethodArgumentNotValidException ex, HttpHeaders headers, HttpStatus status, WebRequest request) {

        ExceptionResource exceptionResource=new ExceptionResource(new Date(),"Validation failed",
                ex.getBindingResult().toString());
        return  new ResponseEntity(exceptionResource, HttpStatus.BAD_REQUEST);
    }

    @Override
    protected ResponseEntity<Object> handleHttpRequestMethodNotSupported(
            HttpRequestMethodNotSupportedException ex, HttpHeaders headers, HttpStatus status, WebRequest request) {
        ExceptionResource exceptionResource = new ExceptionResource(new Date(), "Method Type Not supported",
                request.getDescription(false));
        return new ResponseEntity(exceptionResource, HttpStatus.METHOD_NOT_ALLOWED);


    }
    }


