package com.springbootcamp.springsecurity.repository;

import com.springbootcamp.springsecurity.entities.Seller;
import org.springframework.data.repository.CrudRepository;

public interface SellerRepository extends CrudRepository<Seller,Long>
{
    Seller findByEmail(String email);
    Seller findByConfirmationToken(String confirmationToken);
    //Iterable<Seller> findAll();

}
