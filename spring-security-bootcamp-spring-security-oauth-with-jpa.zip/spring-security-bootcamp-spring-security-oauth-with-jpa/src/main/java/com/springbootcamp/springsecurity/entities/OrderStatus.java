package com.springbootcamp.springsecurity.entities;

import com.springbootcamp.springsecurity.enums.FromStatus;
import com.springbootcamp.springsecurity.enums.ToStatus;

import javax.persistence.*;
import java.io.Serializable;

@Entity
public class OrderStatus implements Serializable
{

    @Id
    @OneToOne
    @JoinColumn(name="order_product_id")
    private OrderProduct orderProduct;

    @Enumerated(EnumType.STRING)
    private FromStatus from_status;

    @Enumerated(EnumType.STRING)
    private ToStatus to_status;

    private String transition_notes_comments;

    public OrderProduct getOrderProduct() {
        return orderProduct;
    }

    public void setOrderProduct(OrderProduct orderProduct) {
        this.orderProduct = orderProduct;
    }

    public FromStatus getFrom_status() {
        return from_status;
    }

    public void setFrom_status(FromStatus from_status) {
        this.from_status = from_status;
    }

    public ToStatus getTo_status() {
        return to_status;
    }

    public void setTo_status(ToStatus to_status) {
        this.to_status = to_status;
    }

    public String getTransition_notes_comments() {
        return transition_notes_comments;
    }

    public void setTransition_notes_comments(String transition_notes_comments) {
        this.transition_notes_comments = transition_notes_comments;
    }

    @Override
    public String toString() {
        return "OrderStatus{" +
                "orderProduct=" + orderProduct +
                ", from_status=" + from_status +
                ", to_status=" + to_status +
                ", transition_notes_comments='" + transition_notes_comments + '\'' +
                '}';
    }
}
