package com.springbootcamp.springsecurity.services;

import com.springbootcamp.springsecurity.entities.Buyer;
import com.springbootcamp.springsecurity.entities.Role;
import com.springbootcamp.springsecurity.repository.BuyerRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.Arrays;
import java.util.UUID;

@Service
public class BuyerService

{
    @Autowired
    BuyerRepository buyerRepository;

    @Autowired
    BCryptPasswordEncoder bCryptPasswordEncoder;

    public String addBuyer(Buyer buyer)
    {
        String buyerPassword=bCryptPasswordEncoder.encode(buyer.getPassword());
        buyer.setPassword(buyerPassword);
        buyer.setRole(Arrays.asList(new Role("ROLE_BUYER")));
        buyer.setIs_active(false);
        buyer.setConfirmationToken(UUID.randomUUID().toString());
        buyer.setExpiryDate(1);
        buyerRepository.save(buyer);
        return "Buyer saved successfully!";
        //Buyer buyer1=new Buyer();



    }
}


