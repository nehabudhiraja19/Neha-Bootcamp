package com.springbootcamp.springsecurity.repository;

import com.springbootcamp.springsecurity.entities.Buyer;
import org.springframework.data.repository.CrudRepository;

public interface BuyerRepository extends CrudRepository<Buyer, Long>
{
    Buyer findByEmail(String email);
    Buyer findByConfirmationToken(String confirmationToken);
}
