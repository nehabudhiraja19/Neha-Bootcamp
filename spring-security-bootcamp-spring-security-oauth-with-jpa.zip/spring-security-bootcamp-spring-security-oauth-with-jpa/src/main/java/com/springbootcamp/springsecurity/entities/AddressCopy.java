package com.springbootcamp.springsecurity.entities;

import javax.persistence.Embeddable;

@Embeddable
public class AddressCopy
{
    private Long addressCopyId;
    private String city;
    private String state;
    private String country;
    private String addressLabel;
    private Integer zipCode;
    private String label;


    AddressCopy(Address orderAddress)
    {
        this.addressCopyId=orderAddress.getAddressId();
        this.city=orderAddress.getCity();
        this.state=orderAddress.getState();
        this.country=orderAddress.getCountry();
        this.addressLabel=orderAddress.getAddressLabel();
        this.label=orderAddress.getLabel();
        this.zipCode=orderAddress.getZipCode();

    }
}
