package com.springbootcamp.springsecurity.exception;

import java.util.Date;

public class ExceptionResource
{
    private Date timestampdate;
    private String message;
    private String detail;

    public ExceptionResource()
    {

    }

    public ExceptionResource(Date timestampdate, String message, String detail) {
        this.timestampdate = timestampdate;
        this.message = message;
        this.detail = detail;
    }

    public Date getTimestampdate() {
        return timestampdate;
    }

    public void setTimestampdate(Date timestampdate) {
        this.timestampdate = timestampdate;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public String getDetail() {
        return detail;
    }

    public void setDetail(String detail) {
        this.detail = detail;
    }
}
