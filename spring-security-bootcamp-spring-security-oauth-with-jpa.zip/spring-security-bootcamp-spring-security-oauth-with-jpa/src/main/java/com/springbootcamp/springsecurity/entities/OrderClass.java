package com.springbootcamp.springsecurity.entities;

import javax.persistence.*;
import java.util.Date;
import java.util.Set;

@Entity
public class OrderClass
{
    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE,generator = "order_generator")
    @SequenceGenerator(name="order_generator",sequenceName="order_seq",allocationSize=1)
    private Long orderClassId;

    private float amount_paid;
    private String payment_method;

    @Temporal(value = TemporalType.DATE)
    private Date order_placed;

    @ManyToOne
    @JoinColumn(name = "user_id")
    Buyer buyer;

    @OneToMany(mappedBy = "orderClass",cascade = CascadeType.ALL,fetch = FetchType.EAGER)

    private Set<OrderProduct> orderProductSet;

   @Embedded
   AddressCopy addressCopy;

    public Long getId() {
        return orderClassId;
    }

    public void setId(Long orderClassId) {
        this.orderClassId = orderClassId;
    }

    public float getAmount_paid() {
        return amount_paid;
    }

    public void setAmount_paid(float amount_paid) {
        this.amount_paid = amount_paid;
    }

    public String getPayment_method() {
        return payment_method;
    }

    public void setPayment_method(String payment_method) {
        this.payment_method = payment_method;
    }

    public Date getOrder_placed() {
        return order_placed;
    }

    public void setOrder_placed(Date order_placed) {
        this.order_placed = order_placed;
    }

    public Buyer getBuyers() {
        return buyer;
    }

    public void setBuyers(Buyer buyers) {
        this.buyer = buyers;
    }

    public AddressCopy getAddressCopy() {
        return addressCopy;
    }

    public void setAddressCopy(AddressCopy addresscopy) {
        this.addressCopy = addresscopy;
    }

    public Buyer getBuyer() {
        return buyer;
    }

    public void setBuyer(Buyer buyer) {
        this.buyer = buyer;
    }

    public Set<OrderProduct> getOrderProductSet() {
        return orderProductSet;
    }

    public void setOrderProductSet(Set<OrderProduct> orderProductSet) {
        this.orderProductSet = orderProductSet;
    }
}
