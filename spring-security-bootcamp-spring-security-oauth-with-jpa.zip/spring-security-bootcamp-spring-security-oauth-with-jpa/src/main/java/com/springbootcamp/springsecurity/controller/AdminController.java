package com.springbootcamp.springsecurity.controller;


import com.springbootcamp.springsecurity.entities.Buyer;
import com.springbootcamp.springsecurity.entities.Seller;
import com.springbootcamp.springsecurity.repository.BuyerPaging;
import com.springbootcamp.springsecurity.repository.BuyerRepository;
import com.springbootcamp.springsecurity.repository.SellerPaging;
import com.springbootcamp.springsecurity.repository.SellerRepository;
import com.springbootcamp.springsecurity.services.BuyerService;
import com.springbootcamp.springsecurity.services.EmailService;
import com.springbootcamp.springsecurity.services.SellerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.web.bind.annotation.*;

@RestController
public class AdminController {
    @Autowired
    BuyerService buyerService;

    @Autowired
    SellerService sellerService;

    @Autowired
    SellerRepository sellerRepository;

    @Autowired
    SellerPaging sellerPaging;

    @Autowired
    BuyerPaging buyerPaging;

    @Autowired
    BuyerRepository buyerRepository;

    @Autowired
    EmailService emailService;


    @GetMapping("/registered/seller")
    public void findAllSeller() {

        Pageable pageable = PageRequest.of(0, 1, Sort.Direction.ASC, "id");

        Page<Seller> sellerPage = sellerPaging.findAll(pageable);/*sellerPaging.findAll(pageable);*/

        sellerPage.forEach(seller -> System.out.println(seller.getId() + " " + seller.getEmail() + " "
                + seller.getFirstName() + " " + seller.getLastName() + " " + seller.isIS_ACTIVE() + " "
                + seller.getCompany_contact() + " " + seller.getCompany_name() + " "));


    }


    @GetMapping("registered/buyer")
    public void findAllBuyer() {
        Pageable pageable = PageRequest.of(0, 10, Sort.Direction.ASC, "user_id");
        Page<Buyer> buyerPage = buyerPaging.findAll(pageable);
        buyerPage.forEach(buyer -> System.out.println(buyer.getId() + " " + buyer.getEmail() + " "
                + buyer.getFirstName() + " " + buyer.getLastName() + " " + buyer.isIS_ACTIVE() + " "));
    }

    @PatchMapping("/buyerFind")
    public String activateBuyer(@RequestParam Long user_id) {
        Buyer buyer = buyerRepository.findById(user_id).get();
        if (buyer == null) {
            throw new UsernameNotFoundException("User not found");
        }
        else if (buyer.isIS_ACTIVE() == false)
        {
            buyer.setIs_active(true);
            buyerRepository.save(buyer);

            SimpleMailMessage registrationEmail = new SimpleMailMessage();
            registrationEmail.setTo(buyer.getEmail());
            registrationEmail.setSubject("Account Activated..");
            registrationEmail.setText("Your account has been activated");
            emailService.sendEmail(registrationEmail);
            return "Your account has been activated now";
        }

        else
        {
            return "Already activated";
        }


    }

    @PatchMapping("/sellerFind")

    public String activateSeller(@RequestParam Long user_id) {
        Seller seller = sellerRepository.findById(user_id).get();
        if (seller == null) {
            throw new UsernameNotFoundException("User not found");
        }
        else if (seller.isIS_ACTIVE() == false)
        {
            seller.setIs_active(true);
            sellerRepository.save(seller);

            SimpleMailMessage registrationEmail = new SimpleMailMessage();
            registrationEmail.setTo(seller.getEmail());
            registrationEmail.setSubject("Account Activated..");
            registrationEmail.setText("Your account has been activated");
            emailService.sendEmail(registrationEmail);
            return "Your account has now been activated";
        }
        else
        {
            return "Already Activated";
        }

    }

    @PatchMapping("/deactivateBuyer")
    public String DeactivateBuyer(@RequestParam Long user_id) {
        Buyer buyer = buyerRepository.findById(user_id).get();

        if (buyer == null) {
            throw new UsernameNotFoundException("User not found");
        } else if (buyer.isIS_ACTIVE() == true) {
            buyer.setIs_active(false);
            buyerRepository.save(buyer);

            SimpleMailMessage registrationEmail = new SimpleMailMessage();
            registrationEmail.setTo(buyer.getEmail());
            registrationEmail.setSubject("Account Deactivated..");
            registrationEmail.setText("Your account has been deactivated");
            emailService.sendEmail(registrationEmail);
            return "Your account has now been deactivated.";
        } else {
            return "Your account is already deactivated..";
        }

    }

    @PatchMapping("/deactivateSeller")
    public String DeactivateSeller(@RequestParam Long user_id) {
        System.out.println("in deactivate seller");
        Seller seller = sellerRepository.findById(user_id).get();
        if (seller == null) {
            throw new UsernameNotFoundException("Seller Not found..");
        } else if (seller.isIS_ACTIVE() == true) {
            seller.setIs_active(false);
            sellerRepository.save(seller);

            SimpleMailMessage registrationEmail = new SimpleMailMessage();
            registrationEmail.setTo(seller.getEmail());
            registrationEmail.setSubject("Account Deactivated..");
            registrationEmail.setText("Your account has been deactivated");
            emailService.sendEmail(registrationEmail);
            return "Your account has been deactivated";
        } else {
            return ("Your account is already deactivated..");
        }


    }
}


