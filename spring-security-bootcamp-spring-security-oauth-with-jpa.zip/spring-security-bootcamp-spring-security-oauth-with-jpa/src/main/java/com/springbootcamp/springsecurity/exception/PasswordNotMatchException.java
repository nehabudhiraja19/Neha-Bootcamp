package com.springbootcamp.springsecurity.exception;

public class PasswordNotMatchException extends RuntimeException
{
    public PasswordNotMatchException(String message)
    {
        super(message);
    }

    public PasswordNotMatchException() {

    }
}
