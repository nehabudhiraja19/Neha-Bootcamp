package com.springbootcamp.springsecurity.entities;

import javax.persistence.*;
import java.util.Set;

@Entity
public class Role
{
    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE,generator = "role_generator")
    @SequenceGenerator(name="role_generator",sequenceName="role_seq",allocationSize=1)
    private Long roleId;
    String authority;
    @ManyToMany(mappedBy = "roles")
    private Set<User> userSet;

    public Role()
    {

    }

    public Set<User> getUserSet() {
        return userSet;
    }

    public void setUserSet(Set<User> userSet) {
        this.userSet = userSet;
    }

    public Role(String authority) {

        this.authority = authority;
    }

    public String getAuthority() {
        return authority;
    }

    public void setAuthority(String authority) {
        this.authority = authority;
    }


    public Long getId() {
        return roleId;
    }

    public void setId(Long roleId) {
        this.roleId = roleId;
    }


}
