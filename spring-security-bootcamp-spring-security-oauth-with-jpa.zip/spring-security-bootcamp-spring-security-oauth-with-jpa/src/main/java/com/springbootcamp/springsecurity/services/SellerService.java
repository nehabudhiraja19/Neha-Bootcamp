package com.springbootcamp.springsecurity.services;

import com.springbootcamp.springsecurity.entities.Role;
import com.springbootcamp.springsecurity.entities.Seller;
import com.springbootcamp.springsecurity.repository.SellerRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.Arrays;
import java.util.UUID;

@Service
public class SellerService
{
    @Autowired
    SellerRepository sellerRepository;

    @Autowired
    BCryptPasswordEncoder bCryptPasswordEncoder;

    public String addSeller(Seller seller)
    {
        String password=  bCryptPasswordEncoder.encode(seller.getPassword());
        seller.setPassword(password);
        seller.setRole(Arrays.asList(new Role("ROLE_SELLER")));

        seller.setIs_active(false);
        seller.setConfirmationToken(UUID.randomUUID().toString());
        seller.setExpiryDate(1);

        //Seller seller1 = new Seller();
        // seller.setPassword(bCryptPasswordEncoder.encode((n)));
        sellerRepository.save(seller);
        return "Seller registered successfully!";



    }

   public Page<Seller> findAllSeller(Pageable pageable)
    {
        return (Page<Seller>) sellerRepository.findAll();
    }

}
