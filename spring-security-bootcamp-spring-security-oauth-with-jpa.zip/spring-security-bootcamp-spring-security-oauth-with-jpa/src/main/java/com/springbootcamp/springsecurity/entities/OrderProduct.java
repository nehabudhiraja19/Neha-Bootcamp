package com.springbootcamp.springsecurity.entities;

import javax.persistence.*;

@Entity
public class OrderProduct
{

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE,generator = "orderProduct_generator")
    @SequenceGenerator(name="orderProduct_generator",sequenceName="orderProduct_seq",allocationSize=1)
    private Long orderProductId;
    private Integer quantity;
    private Double price;

    @ManyToOne
    @JoinColumn(name = "order_id")
    private OrderClass orderClass;

    @OneToOne
    @JoinColumn(name = "product_variation_id")
    private ProductVariation productVariation;

    @Column(columnDefinition = "JSON")
    private String order_metadata;

    @OneToOne(mappedBy = "orderProduct")
    private OrderStatus orderStatus;

    public Long getOrderProductId() {
        return orderProductId;
    }

    public void setOrderProductId(Long orderProductId) {
        this.orderProductId = orderProductId;
    }

    public Integer getQuantity() {
        return quantity;
    }

    public void setQuantity(Integer quantity) {
        this.quantity = quantity;
    }

    public Double getPrice() {
        return price;
    }

    public void setPrice(Double price) {
        this.price = price;
    }

    public OrderClass getOrderClass() {
        return orderClass;
    }

    public void setOrderClass(OrderClass orderClass) {
        this.orderClass = orderClass;
    }

    public ProductVariation getProductVariation() {
        return productVariation;
    }

    public void setProductVariation(ProductVariation productVariation) {
        this.productVariation = productVariation;
    }

    public String getOrder_metadata() {
        return order_metadata;
    }

    public void setOrder_metadata(String order_metadata) {
        this.order_metadata = order_metadata;
    }

    public OrderStatus getOrderStatus() {
        return orderStatus;
    }

    public void setOrderStatus(OrderStatus orderStatus) {
        this.orderStatus = orderStatus;
    }
}


