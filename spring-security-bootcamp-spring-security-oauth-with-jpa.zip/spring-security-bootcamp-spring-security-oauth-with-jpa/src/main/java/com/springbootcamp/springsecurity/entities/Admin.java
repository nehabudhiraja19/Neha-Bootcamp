package com.springbootcamp.springsecurity.entities;


public class Admin extends User
{

}
