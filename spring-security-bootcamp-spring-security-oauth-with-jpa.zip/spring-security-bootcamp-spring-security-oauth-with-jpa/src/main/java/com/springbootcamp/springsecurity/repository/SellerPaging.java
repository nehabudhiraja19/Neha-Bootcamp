package com.springbootcamp.springsecurity.repository;

import com.springbootcamp.springsecurity.entities.Seller;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.repository.PagingAndSortingRepository;

public interface SellerPaging extends PagingAndSortingRepository<Seller,Long>
{
    //Iterable<Seller> findAll();
    public Page<Seller> findAll(Pageable pageable);
}
