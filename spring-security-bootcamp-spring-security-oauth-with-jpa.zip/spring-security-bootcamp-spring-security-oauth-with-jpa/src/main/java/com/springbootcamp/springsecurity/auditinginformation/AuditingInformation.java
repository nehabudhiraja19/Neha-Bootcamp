package com.springbootcamp.springsecurity.auditinginformation;

import javax.persistence.Embeddable;
import java.util.Date;

@Embeddable

public class AuditingInformation
{
    public Date date_created;
    public Date last_updated;
    public String created_by;
    public String updated_by;


    public Date getDate_created() {
        return date_created;
    }

    public void setDate_created(Date date_created) {
        this.date_created = date_created;
    }

    public Date getLast_updated() {
        return last_updated;
    }

    public void setLast_updated(Date last_updated) {
        this.last_updated = last_updated;
    }

    public String getCreated_by() {
        return created_by;
    }

    public void setCreated_by(String created_by) {
        this.created_by = created_by;
    }

    public String getUpdated_by() {
        return updated_by;
    }

    public void setUpdated_by(String updated_by) {
        this.updated_by = updated_by;
    }
}
