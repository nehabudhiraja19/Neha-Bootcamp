//package com.springbootcamp.springsecurity;
//
//
//import com.springbootcamp.springsecurity.Entities.Buyer;
//import com.springbootcamp.springsecurity.Entities.Role;
//import com.springbootcamp.springsecurity.Entities.Seller;
//import com.springbootcamp.springsecurity.Entities.User;
//import com.springbootcamp.springsecurity.Repository.UserRepository;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.boot.ApplicationArguments;
//import org.springframework.boot.ApplicationRunner;
//import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
//import org.springframework.security.crypto.password.PasswordEncoder;
//import org.springframework.stereotype.Component;
//
//import java.util.*;
//
//@Component
//public class Bootstrap implements ApplicationRunner {
//
//    @Autowired
//    UserRepository userRepository;
//
//    @Override
//    public void run(ApplicationArguments args) throws Exception {
//        PasswordEncoder passwordEncoder = new BCryptPasswordEncoder();
//        Seller user1 = new Seller();
//        user1.setUsername("user10");
//        user1.setEmail("neha.budhiraja@tothenew.com");
//        user1.setFirstname("Neha");
//        user1.setMiddlename("Singh");
//        user1.setLastname("Budhiraja");
//        user1.setIs_active(false);
//        user1.setIS_DELETED(false);
//        user1.setGST(19f);
//        user1.setCompany_contact("987656123");
//        user1.setCompany_name("TTN");
//        user1.setPassword(passwordEncoder.encode("NehaBudhiraja@123"));
//        List<Role> roles = new LinkedList<>();
//        // roles.add(new Role("ROLE_USER"));
//        roles.add(new Role("ROLE_SELLER"));
//        roles.add(new Role("ROLE_ADMIN"));
//        user1.setRole(roles);
//        userRepository.save(user1);
//    }
//}
//
//////        Buyer user2 = new Buyer();
//////        user2.setUsername("admin");
//////        user2.setContact("987654532");
//////        user2.setPassword(passwordEncoder.encode("pass"));
//////        List<Role> roles1 = new LinkedList<>();
//////        roles1.add(new Role("ROLE_ADMIN"));
//////        //roles1.add(new Role("ROLE_USER"));
//////        user2.setRole(roles1);
//////        userRepository.save(user2);
////        System.out.println("Total users saved::" + userRepository.count());
////
////
////
////    }
////}
