package com.springbootcamp.springsecurity.exception;

public class EmailNotValidException extends RuntimeException
{
    public EmailNotValidException() {
    }

    public EmailNotValidException(String message) {
        super(message);
    }
}
