package com.springbootcamp.springsecurity.entities;

import javax.persistence.*;
import java.io.Serializable;

@Entity
public class ProductReview implements Serializable
{
    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE,generator = "productReview_generator")
    @SequenceGenerator(name="productReview_generator",sequenceName="productReview_seq",allocationSize=1)

    private Long productReviewId;
    private String review;
    private Integer rating;

    @Id
    @ManyToOne
    @JoinColumn(name = "buyer_user_id")
    private Buyer buyer;

    @Id
    @ManyToOne
    @JoinColumn(name="product_id")
    private Product product;

    public String getReview() {
        return review;
    }

    public void setReview(String review) {
        this.review = review;
    }

    public Integer getRating() {
        return rating;
    }

    public void setRating(Integer rating) {
        this.rating = rating;
    }

    public Buyer getBuyer() {
        return buyer;
    }

    public void setBuyer(Buyer buyer) {
        this.buyer = buyer;
    }

    public Product getProduct() {
        return product;
    }

    public void setProduct(Product product) {
        this.product = product;
    }

    public Long getProductReviewId() {
        return productReviewId;
    }

    public void setProductReviewId(Long productReviewId) {
        this.productReviewId = productReviewId;
    }
}
