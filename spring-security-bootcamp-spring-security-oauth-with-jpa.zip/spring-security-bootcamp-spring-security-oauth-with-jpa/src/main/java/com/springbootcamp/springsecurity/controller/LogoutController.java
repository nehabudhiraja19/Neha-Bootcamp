package com.springbootcamp.springsecurity.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.oauth2.common.OAuth2AccessToken;
import org.springframework.security.oauth2.provider.token.TokenStore;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class LogoutController
{
    @Autowired
    private TokenStore tokenStore;


    @PostMapping("/Logout")
    public String Logout(@RequestParam String token)
    {

        OAuth2AccessToken accessToken=tokenStore.readAccessToken(token);
        tokenStore.removeAccessToken(accessToken);

        return "Logout Successfully";
    }

}
