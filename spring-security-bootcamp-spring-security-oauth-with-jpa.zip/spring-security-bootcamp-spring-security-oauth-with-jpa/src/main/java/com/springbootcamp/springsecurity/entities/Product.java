package com.springbootcamp.springsecurity.entities;

import javax.persistence.*;
import java.util.Set;

@Entity
public class Product
{
    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE,generator = "product_generator")
    @SequenceGenerator(name="product_generator",sequenceName="product_seq",allocationSize=1)
    private Long productId;
    private String name;
    private String description;
    private boolean IS_CANCELLABLE;
    private boolean IS_RETURNABLE;
    private String Brand;
    private boolean IS_ACTIVE;


    @ManyToMany
    @JoinTable(name = "seller_user_id",joinColumns = @JoinColumn(name="product_id",
            referencedColumnName = "productId"),
            inverseJoinColumns = @JoinColumn(name="seller_id",referencedColumnName = "user_id"))
    private Set<Seller> sellers;

    @ManyToOne
    @JoinColumn(name="category_id")
    private Category category;

    @OneToMany(mappedBy = "product",cascade = CascadeType.ALL,fetch = FetchType.LAZY)
    Set<ProductVariation> productVariationSet;

    @OneToMany(mappedBy = "product",cascade = CascadeType.ALL,fetch = FetchType.LAZY)
    private Set<ProductReview>productReviewSet;


    public Set<ProductReview> getProductReviewSet() {
        return productReviewSet;
    }

    public void setProductReviewSet(Set<ProductReview> productReviewSet) {
        this.productReviewSet = productReviewSet;
    }



    public Set<ProductVariation> getProductVariationSet() {
        return productVariationSet;
    }

    public void setProductVariationSet(Set<ProductVariation> productVariationSet) {
        this.productVariationSet = productVariationSet;
    }


    public Long getId() {
        return productId;
    }

    public void setId(Long id) {
        this.productId = productId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Set<Seller> getSellerSet() {
        return sellers;
    }

    public void setSellerSet(Set<Seller> seller) {
        this.sellers= seller;
    }

    public Category getCategory() {
        return category;
    }

    public void setCategory(Category category) {
        this.category = category;
    }

    public boolean isIS_CANCELLABLE() {
        return IS_CANCELLABLE;
    }

    public void setIS_CANCELLABLE(boolean IS_CANCELLABLE) {
        this.IS_CANCELLABLE = IS_CANCELLABLE;
    }

    public boolean isIS_RETURNABLE() {
        return IS_RETURNABLE;
    }

    public void setIS_RETURNABLE(boolean IS_RETURNABLE) {
        this.IS_RETURNABLE = IS_RETURNABLE;
    }

    public String getBrand() {
        return Brand;
    }

    public void setBrand(String brand) {
        Brand = brand;
    }

    public boolean isIS_ACTIVE() {
        return IS_ACTIVE;
    }

    public void setIS_ACTIVE(boolean IS_ACTIVE) {
        this.IS_ACTIVE = IS_ACTIVE;
    }
}
