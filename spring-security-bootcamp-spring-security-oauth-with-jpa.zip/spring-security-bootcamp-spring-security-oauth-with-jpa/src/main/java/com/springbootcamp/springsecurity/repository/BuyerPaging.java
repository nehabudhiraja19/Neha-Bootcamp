package com.springbootcamp.springsecurity.repository;

import com.springbootcamp.springsecurity.entities.Buyer;
import org.springframework.data.repository.PagingAndSortingRepository;

public interface BuyerPaging extends PagingAndSortingRepository<Buyer,Long>
{

}
